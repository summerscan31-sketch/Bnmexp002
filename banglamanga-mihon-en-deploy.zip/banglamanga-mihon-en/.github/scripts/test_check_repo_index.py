import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("check_repo_index.py")
PACKAGE = "eu.kanade.tachiyomi.extension.en.banglamanga"


def make_index(version_code=106001, version_name="1.6.1", apk_url="https://example.invalid/v1.6.1/app.apk"):
    return {
        "name": "BanglaManga (English titles)",
        "signingKey": "a" * 64,
        "extensionList": {
            "extensions": [
                {
                    "name": "BanglaManga (English titles)",
                    "packageName": PACKAGE,
                    "resources": {"apkUrl": apk_url, "iconUrl": "https://example.invalid/icon.png"},
                    "extensionLib": "1.6",
                    "versionCode": str(version_code),
                    "versionName": version_name,
                    "contentWarning": "CONTENT_WARNING_MIXED",
                    "sources": [],
                }
            ]
        },
    }


class CheckRepoIndexTests(unittest.TestCase):
    def run_check(self, previous, current):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            previous_path = temp / "previous.json"
            current_path = temp / "current.json"
            previous_path.write_text(json.dumps(previous), encoding="utf-8")
            current_path.write_text(json.dumps(current), encoding="utf-8")
            return subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--previous-index",
                    str(previous_path),
                    "--current-index",
                    str(current_path),
                ],
                check=False,
                capture_output=True,
                text=True,
            )

    def test_allows_a_newer_version_and_an_identical_rerun(self):
        previous = make_index()
        newer = make_index(106002, "1.6.2", "https://example.invalid/v1.6.2/app.apk")
        newer_result = self.run_check(previous, newer)
        self.assertEqual(newer_result.returncode, 0, newer_result.stderr)
        same_result = self.run_check(previous, previous)
        self.assertEqual(same_result.returncode, 0, same_result.stderr)

    def test_rejects_downgrades_and_changed_index_without_version_bump(self):
        previous = make_index()
        older = make_index(106000, "1.6.0", "https://example.invalid/v1.6.0/app.apk")
        older_result = self.run_check(previous, older)
        self.assertNotEqual(older_result.returncode, 0)
        self.assertIn("older", older_result.stderr.lower())

        same_code_changed_entry = make_index(106001, "1.6.1", "https://example.invalid/replaced.apk")
        same_code_result = self.run_check(previous, same_code_changed_entry)
        self.assertNotEqual(same_code_result.returncode, 0)
        self.assertIn("versioncode", same_code_result.stderr.lower())


if __name__ == "__main__":
    unittest.main()
