# Framework notice

This repository includes build and runtime framework components from [Keiyoushi/extensions-source](https://github.com/keiyoushi/extensions-source), licensed under Apache License 2.0. The upstream project is not affiliated with this extension or its target website. See `LICENSE` for the license text.
