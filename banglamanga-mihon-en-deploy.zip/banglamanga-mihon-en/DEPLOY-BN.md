# Mihon-এ BanglaManga extension repository চালু করুন

এই প্রজেক্টের release workflow একটি signed APK তৈরি করে, GitHub Release-এ রাখে, তারপর `repo` branch-এ Mihon-এর repository index প্রকাশ করে। সফল প্রথম release-এর পরেই Mihon-এ পেস্ট করার URL কাজ করবে। আধুনিক Mihon repository-র জন্য এখানে `index.pb` ব্যবহার করা হয়েছে; [Mihon-compatible store guide](https://keiyoushi.github.io/docs/guides/getting-started) অনুযায়ী Mihon **0.21.3 বা নতুন সংস্করণ** ব্যবহার করুন।

## ১. নিজের public GitHub repository তৈরি করুন

GitHub-এ নিজের account-এ একটি **Public** repository তৈরি করুন। নাম আপনার পছন্দের—এই নির্দেশনায় কোনো username বা repository name ধরে নেওয়া হয়নি। GitHub-এ শুরুতে README, `.gitignore` বা license যোগ করবেন না; সেগুলো প্রজেক্ট ZIP-এ আছে। Default branch `main` রাখুন। Repository private হলে Mihon থেকে index/APK পড়া যাবে না।

ZIP extract করে project-এর root folder-এ terminal খুলুন। ZIP-এ `.git` history থাকে না, তাই local Git repository initialize করে push করুন:

```bash
git init -b main
git add .
git commit -m "Initial BanglaManga Mihon extension"
git remote add origin https://github.com/<GITHUB_USERNAME>/<REPOSITORY_NAME>.git
git push -u origin main
```

`<GITHUB_USERNAME>` ও `<REPOSITORY_NAME>`-এর জায়গায় আপনার আসল GitHub username এবং তৈরি করা repository name লিখবেন; angle bracket-গুলো লিখবেন না।

## ২. GitHub Actions-এর write permission দিন

আপনার repository-তে **Settings → Actions → General → Workflow permissions** খুলে **Read and write permissions** চালু করুন এবং save করুন। Actions চালু আছে কিনা নিশ্চিত করুন। Release workflow এই permission দিয়ে `repo` branch তৈরি/আপডেট করবে। GitHub Pages সেটআপ করতে হবে না।

## ৩. Release signing key তৈরি ও GitHub Secrets যোগ করুন

একই signing key দিয়ে ভবিষ্যতের সব update sign করতে হবে। Key হারালে বা বদলালে Mihon আগের extension-কে update হিসেবে গ্রহণ নাও করতে পারে। Key-টি project/repository-তে commit করবেন না; নিরাপদ backup রাখুন।

নিজের কম্পিউটারে key তৈরি করুন:

```bash
keytool -genkeypair -v -keystore signingkey.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias banglamanga
```

তারপর repository-র **Settings → Secrets and variables → Actions → New repository secret** থেকে নিচের চারটি secret যোগ করুন:

| Secret name | কী দিতে হবে |
|---|---|
| `SIGNING_KEY` | `signingkey.jks` ফাইলের এক লাইনের Base64 text; Linux-এ `base64 -w0 signingkey.jks`, macOS-এ `base64 signingkey.jks \| tr -d '\n'` চালিয়ে নিন |
| `KEY_STORE_PASSWORD` | key তৈরি করার সময় দেওয়া keystore password |
| `ALIAS` | উপরের উদাহরণে `banglamanga` |
| `KEY_PASSWORD` | key তৈরির সময় দেওয়া key password |

এই password-গুলো chat-এ বা source file-এ লিখবেন না। `.jks` ফাইলটি নিজে নিরাপদে রেখে দিন—পরবর্তী release-এ একই key দরকার হবে।

## ৪. প্রথম release চালান

এই ZIP-এর বর্তমান extension version `1.6.1` (`libVersion = "1.6"`, `versionCode = 1`)। Main branch push হওয়ার পর প্রথম release tag দিন:

```bash
git tag v1.6.1
git push origin v1.6.1
```

GitHub-এ **Actions → Release Mihon extension** খুলে run সম্পূর্ণ সফল হওয়া পর্যন্ত অপেক্ষা করুন। Workflow signed APK-টি GitHub Release-এ প্রকাশ করে; এরপর `repo` branch-এ `repo.json`, `index.pb`, `index.json` ও icon প্রকাশ করে। একই signing certificate আগের release-এর সঙ্গে না মিললে workflow publish বন্ধ করবে—এটি update key বদলে যাওয়া ঠেকায়।

যদি GitHub Release তৈরি হয় কিন্তু `Publish Mihon repository index` ধাপে workflow ব্যর্থ হয়, Actions-এ ওই failed run খুলে **Re-run jobs** দিন। এতে একই tag-এর APK/index আবার প্রকাশের চেষ্টা হবে; `repo` branch ইতিমধ্যে আপডেট থাকলে কাজটি idempotent। Workflow পুরোনো `versionCode` reject করলে পুরোনো tag rerun করবেন না—আগের চেয়ে বড় `versionCode` দিয়ে নতুন matching tag দিন।

## ৫. Mihon-এর extension store-এ URL paste করুন

প্রথম release-এর পর নিচের template-এ নিজের username ও repository name বসিয়ে পুরো URL কপি করুন:

```text
https://github.com/<GITHUB_USERNAME>/<REPOSITORY_NAME>/raw/repo/index.pb
```

Mihon-এ **More → Settings → Browse → Extension store → Add** খুলে URL-টি paste করুন। Mihon-এর অন্য সংস্করণে menu-র নাম সামান্য আলাদা হতে পারে; `Extension store`/repository যোগ করার জায়গাটি ব্যবহার করুন। GitHub repository page বা শুধু `.git` URL নয়—উপরের `index.pb`-এর পুরো URL-টাই লাগবে।

## ভবিষ্যতের update

নতুন extension release দিতে হলে `src/en/banglamanga/build.gradle.kts`-এ `versionCode` বাড়ান—যেমন `1` থেকে `2`—তারপর নতুন source commit push করুন এবং matching version tag push করুন:

```bash
git add src/en/banglamanga/build.gradle.kts
git commit -m "Prepare extension version 1.6.2"
git push origin main
git tag v1.6.2
git push origin v1.6.2
```

Workflow APK ও index দুটোই আপডেট করবে; Mihon-এ আগে থেকে যোগ করা repository URL বদলাতে হবে না। আগের `signingkey.jks` ও তার password অক্ষত রাখুন। অন্য উৎস/সই দিয়ে একই package আগে install করা থাকলে নতুন self-hosted build বসানোর আগে পুরোনো extension uninstall করতে হতে পারে।

> এই extension Mihon-এর English (`en`) category-তে থাকে এবং English title-সহ catalog item দেখায়; এতে chapter scan-ও ইংরেজি—এ নিশ্চয়তা নেই। Extensionটি ad/shortener বা login/CAPTCHA/অন্যান্য access gate এড়িয়ে যায় না।
