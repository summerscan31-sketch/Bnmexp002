# BanglaManga for Mihon — English source

This extension is registered in Mihon's English (`en`) source category (`src/en` and `lang = "en"`). It also applies an internal catalog filter: only rows with a non-blank `title_en` value are listed. It does not filter by a Bengali original-language field.

> **Important language limitation:** the English source category and English-title filter do not prove the chapter scans are English. BanglaManga's public catalog does not label chapter-image language, and its public chapter labels are Bengali. Check a series on the site before adding it to your library.

This is an installable **Mihon extension APK**, not a full reader app. It uses the [Keiyoushi extension build framework](https://github.com/keiyoushi/extensions-source) and Apache-2.0-licensed framework components. It does not bundle manga images.

## What it does

- Provides search plus popular/latest catalog views, filtered to manga with an English title.
- Lists published chapters and labels them in English (`Chapter 1`, etc.) instead of displaying Bengali chapter titles.
- Loads page images from the site's public catalog/media endpoints after checking the expected BanglaManga CDN or public Supabase storage paths.
- Discovers the public data endpoint from the site's own JavaScript bundle at runtime; no account credentials or copied API key are stored in this repository.
- Does not resolve external short links, automate ads, or bypass login, CAPTCHA, verification, or other access gates. The site's [ad guide](https://www.banglamanga.com/ad-guide) notes that sponsored ads may open in a browser tab in its web reader. This extension uses direct catalog/media requests and does not reproduce that web UI; if a required shortener or gate is later inserted into the image/API flow, the extension will stop rather than skip it.

Use only material you are entitled to access. See BanglaManga's [copyright/removal page](https://www.banglamanga.com/copyright). This community project is not affiliated with BanglaManga or Mihon.

## Build and test

Prerequisites: JDK 17 or newer, Android SDK platform 37, and an internet connection for Gradle dependencies.

```bash
./gradlew :parser-tests:test
./gradlew :src:en:banglamanga:assembleDebug
```

The parser tests live in a small Kotlin/JVM module so test-only code is not packaged in the extension APK or run through the source generator.

The local debug APK is generated at:

```text
src/en/banglamanga/build/outputs/apk/debug/tachiyomi-en.banglamanga-v1.6.1.apk
```

It is signed with a debug key for testing. Debug APKs produced on different machines or GitHub runners may have different signatures; install future updates with the same signing key or uninstall the old debug build first.

## GitHub Actions release

- `build.yml` runs the parser and repository-index tests, then uploads a debug APK artifact on pushes to `main`, pull requests, and manual runs.
- `release.yml` runs when you push a `v*` tag. It builds and publishes the release APK as a GitHub Release asset, then publishes Mihon's `repo.json` and `index.pb` to the `repo` branch.

For a public GitHub repository, add this URL in Mihon's extension store (Mihon 0.21.3 or newer):

```text
https://github.com/<GITHUB_USERNAME>/<REPOSITORY_NAME>/raw/repo/index.pb
```

Replace both placeholders with your account and repository names. The branch and index are created by the first successful tagged release; see the [Bangla deployment guide](DEPLOY-BN.md) for setup and signing-key steps.

For updateable releases, create and keep your own Android signing key private. **Never commit the keystore or its passwords.** The release workflow requires these repository Actions secrets:

- `SIGNING_KEY`: the keystore file encoded as one Base64 string.
- `KEY_STORE_PASSWORD`: the keystore password.
- `ALIAS`: the key alias.
- `KEY_PASSWORD`: the key password.

A JKS key can be generated locally with `keytool -genkeypair -v -keystore signingkey.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias banglamanga`. Encode it for the `SIGNING_KEY` secret with `base64 -w0 signingkey.jks` on Linux (`base64 signingkey.jks | tr -d '\n'` on macOS). Keep the original keystore safe: every future release must use the same key to update an installed APK.

After updating the module's `versionCode` in `src/en/banglamanga/build.gradle.kts`, push a matching tag, for example:

```bash
git tag v1.6.2
git push origin v1.6.2
```

## Install the extension

Install the APK on your Android device and allow installation if Android prompts you. In Mihon, open **Browse → Sources** and search for **BanglaManga (English titles)**. To add the self-hosted extension store, follow the URL and setup steps above.

## Maintenance note

This integration depends on BanglaManga's public API schema and CDN/storage paths. If the site changes those, update the parser/source and its tests. The English source category is a Mihon classification; the built-in `title_en` filter is a catalog filter, not an English-translation guarantee.
