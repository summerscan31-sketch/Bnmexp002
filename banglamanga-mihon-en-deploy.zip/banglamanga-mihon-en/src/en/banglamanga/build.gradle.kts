import io.github.keiyoushi.gradle.api.ContentWarning

plugins {
    alias(kei.plugins.extension)
}

keiyoushi {
    name = "BanglaManga (English titles)"
    versionCode = 1
    contentWarning = ContentWarning.MIXED
    libVersion = "1.6"
    source {
        baseUrl = "https://www.banglamanga.com"
        lang = "en"
    }
}
