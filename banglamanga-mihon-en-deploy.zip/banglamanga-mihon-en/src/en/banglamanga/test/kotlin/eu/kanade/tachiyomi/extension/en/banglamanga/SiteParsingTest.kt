package eu.kanade.tachiyomi.extension.en.banglamanga

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SiteParsingTest {
    @Test
    fun `extracts the public Supabase endpoint and anon token from the site bundle`() {
        val parsed = parseSupabaseConfig(
            "https://project-x.supabase.co\",client=\"eyJheader.payload.signature\"",
        )

        assertNotNull(parsed)
        assertEquals("https://project-x.supabase.co", parsed?.url)
        assertEquals("eyJheader.payload.signature", parsed?.anonKey)
    }

    @Test
    fun `rejects a non Supabase endpoint`() {
        assertNull(parseSupabaseConfig("https://evil.example\",client=\"eyJheader.payload.signature\""))
        assertNull(parseSupabaseConfig("http://project-x.supabase.co\",client=\"eyJheader.payload.signature\""))
    }

    @Test
    fun `English catalog filter requires a nonblank English title`() {
        assertTrue(hasEnglishTitle("Blue Lock"))
        assertFalse(hasEnglishTitle(null))
        assertFalse(hasEnglishTitle("  "))
    }

    @Test
    fun `image URL validation permits only the site's published image paths`() {
        val storageHost = "wgeydzfmtehdkosxwnai.supabase.co"

        assertTrue(isAllowedImageUrl("https://cdn.banglamanga.com/chapters/demo/ch-1/page.webp", storageHost))
        assertTrue(
            isAllowedImageUrl(
                "https://$storageHost/storage/v1/object/public/manga/covers/demo.webp",
                storageHost,
            ),
        )
        assertFalse(isAllowedImageUrl("https://short.example/abc", storageHost))
        assertFalse(isAllowedImageUrl("http://cdn.banglamanga.com/chapters/demo/page.webp", storageHost))
        assertFalse(isAllowedImageUrl("https://cdn.banglamanga.com/private/demo.webp", storageHost))
        assertFalse(isAllowedImageUrl("https://cdn.banglamanga.com.evil.example/chapters/demo/page.webp", storageHost))
    }
}
